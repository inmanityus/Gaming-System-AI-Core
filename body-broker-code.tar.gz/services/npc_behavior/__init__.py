"""
NPC Behavior Service - AI-driven NPC behavior management.
"""

from behavior_engine import BehaviorEngine

__all__ = [
    "BehaviorEngine",
]
