"""Cache service for multi-tier architecture."""

