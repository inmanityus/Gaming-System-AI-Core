"""
Pytest configuration for Quest System Service tests.
"""

