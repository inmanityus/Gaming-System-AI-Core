"""
Configuration & Settings Service
Manages game configuration, player preferences, feature flags, and settings with hot-reload.
"""

__version__ = "0.1.0"

