"""
Protobuf generated code for Language System gRPC service
"""

from . import language_service_pb2
from . import language_service_pb2_grpc

__all__ = ['language_service_pb2', 'language_service_pb2_grpc']

