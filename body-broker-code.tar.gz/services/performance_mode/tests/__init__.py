"""Tests for Performance Mode Service."""


