"""
Tests for Weather Manager service.
"""






