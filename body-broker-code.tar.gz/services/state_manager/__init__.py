"""
State Management Service
Provides centralized game state management with Redis Cluster caching and PostgreSQL persistence.
"""

__version__ = "0.1.0"

